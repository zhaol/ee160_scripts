#include <stdio.h>

int main() {
  printf("It was nice meeting you, world.\n");
  printf("Hope to see you again soon. :-\\\n");
  printf("Don't forget to write.\n");
  return 0;
}