#include <stdio.h>

main() {
  int integer;

  printf("Please enter an integer:");
  scanf("%d", &integer);
  printf ("integer: %i\n", integer);
}